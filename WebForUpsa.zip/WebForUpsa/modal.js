// Obtener el modal
var modal = document.getElementById("flagModal");
var span = document.getElementsByClassName("close")[0];

// Función para abrir el modal
function abrirModal() {
  modal.style.display = "block";
}

// Función para cerrar el modal
span.onclick = function() {
  modal.style.display = "none";
}

// Función para guardar la bandera
function guardarBandera() {
  var flag = document.getElementById("flagInput").value;
  // Aquí puedes añadir código para mostrar la bandera en el reto correspondiente
  // Por ejemplo, document.getElementById("idDelReto").innerText = flag;
  modal.style.display = "none";
}

// Cerrar el modal si se hace clic fuera de él
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}

